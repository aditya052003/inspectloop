# InspectLoop submission package

This archive contains the final portrait-alignment code, reproducible setup,
architecture, technical report, tests and evaluation evidence.

## Judge navigation
- Source and run instructions: inspectloop/README.md
- Technical report: inspectloop/docs/TECHNICAL_REPORT.md (including final update)
- Architecture: inspectloop/docs/ARCHITECTURE.md
- Cloud infrastructure: inspectloop/template.yaml and Dockerfile
- Actual reviewed cloud photo report: inspectloop/evaluation/real-photo-cloud-report.json
- Tests: inspectloop/tests/ (19 passed locally)

Live app: https://620mowl7mj.execute-api.ap-south-1.amazonaws.com

The inspection API requires an access token. The participant must provide it
separately in private judge-access instructions; no credential is included here.
For local reproduction follow README.md; a token is not required by default
when running locally without cloud environment variables.

The video is supplied separately via the Devpost video field. This archive does
not contain a video and does not itself complete submission.

## Evidence limits
The synthetic evaluation is historical development evidence. The real-photo
pair informed an alignment correction and still yields background flags.
There is no independent accuracy claim, baseline comparison, or benefit study.
The deployment update and real-photo workflow were completed by the participant
and documented through terminal output, screenshots and the exported report.
