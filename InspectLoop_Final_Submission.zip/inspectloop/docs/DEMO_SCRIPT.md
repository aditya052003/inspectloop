# InspectLoop: 3–4 minute recording

Prepare the AWS website with the token already entered, then collapse Protected deployment access. Open the technical report, architecture diagram, and evaluation/cloud-verification.json in separate windows. Do not expose secrets or private AWS console details.

## 0:00–0:25 — Introduce yourself (show yourself briefly)
“Hi, I'm Aditya Raut. This is InspectLoop, a visual inspection prototype built with OpenCV 5 and AWS. It checks whether a photograph is suitable for inspection, highlights visible changes, and keeps the final decision with a person.”

## 0:25–1:10 — Run Missing component
“This is a synthetic assembly example. On the left is the reference. On the right, one component is missing. The system highlights that region and asks for review. I can inspect the original image, overlay, and difference mask.”
Switch the views, enter “Missing component in the synthetic sample,” then click Confirm defect. If the review fails, resolve it before recording; do not narrate a success that did not occur.
“The observation and human decision are recorded separately. I can download the evidence report.”

## 1:10–2:00 — Show adaptive behavior
Run Dim capture + defect and expand Exposure Recovery in the trace.
“Here, the brightness measurement changes the next tool call. The controller corrects exposure and checks the image again before comparison.”
Run Out of focus.
“This image is too blurry. The system asks for a new capture instead of reporting a confident inspection result. Retakes are separate inspections in this version.”

## 2:00–2:40 — Architecture
Show docs/ARCHITECTURE.md in rendered Markdown preview.
“OpenCV performs quality measurement, feature matching, alignment and local difference analysis. The controller is deterministic, not an LLM. The same workload runs inside AWS Lambda. API Gateway serves requests, and private S3 storage holds reports. Inspection endpoints require an access token.”

## 2:40–3:20 — Evidence
Show evaluation/cloud-verification.json and summary.json.
“The live cloud test confirmed OpenCV 5, Lambda execution, saved-report retrieval, and rejection of requests without a token. That one request took about 432 milliseconds; this is not a latency benchmark. Our local tests passed, and 80 synthetic development examples followed the expected route. They are not a held-out real-world dataset.”

## 3:20–3:50 — Limitations and close
“Tiny, low-contrast and color-only changes can be missed. We include failure examples rather than treating no detected change as proof of quality. The next step is independent real-product validation and comparison with a simpler baseline. I used AI assistance in implementation and documentation. Thank you.”

After recording: ensure it is under five minutes, audible, readable, accessible to judges and free of exposed tokens. Do not submit this script as a replacement for the actual video.
