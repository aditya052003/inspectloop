# InspectLoop — finish and submit

This package contains source code, an updated technical report, architecture diagrams, evaluation evidence, Devpost text, and a short video script. It does not submit anything automatically.

## Do these now
1. Keep your existing deployed app running. Do not replace your local working folder or redeploy merely to use this package.
2. Read DEVPOST_TEXT.md and paste the appropriate sections into your submission. Review every claim.
3. Record the walkthrough in VIDEO_SCRIPT.md (target 3–4 minutes; maximum five). Hide the access-token panel while recording.
4. Upload the video as unlisted/public and add its URL to Devpost. Test playback in a signed-out browser.
5. Supply the source archive through an allowed judge-accessible archive field, or upload the inspectloop folder to a repository and provide that link. Do not commit tokens, .env, samconfig.toml, .venv, or local report folders.
6. Attach/link inspectloop/docs/TECHNICAL_REPORT.md and ARCHITECTURE.md where supported. A repository renders these Markdown files; VS Code Markdown preview is also suitable for your recording.
7. Provide the live endpoint. Share the access token only in a designated private judge-instructions field. If no private field exists, ask the organizers for an approved access method or arrange the permitted live demonstration; do not assume judges can use the app without the token.
8. Check all required fields, click final Submit, and verify the submission confirmation.

Endpoint: https://620mowl7mj.execute-api.ap-south-1.amazonaws.com

## If you have time for one more validation task
Take a fixed-camera reference photo of a parts tray and a second photo with one item removed. Run the upload path. Record the actual result, including failure. This is a pilot example, not a reliable accuracy study. Do not delay essential video/access/submission tasks waiting for a large dataset.

## Remaining limitations
No real-product evaluation or user-benefit study is available. The 80 synthetic cases were used during development. No baseline comparison is available. The app requests retakes but does not link follow-up photographs. Agentic Vision eligibility is for organizers to determine. No outcome or prize is guaranteed.
