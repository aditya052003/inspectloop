"""Regression coverage for portrait movement and excessive camera motion."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import cv2
import numpy as np
from vision import inspect


def textured_portrait():
    rng = np.random.default_rng(23)
    image = np.full((853, 640, 3), 130, np.uint8)
    for _ in range(350):
        x, y = rng.integers([30, 30], [610, 820])
        color = tuple(int(v) for v in rng.integers(30, 230, 3))
        cv2.circle(image, (int(x), int(y)), 5, color, -1)
    return image


def test_portrait_translation_with_good_overlap():
    ref = textured_portrait()
    candidate = cv2.warpAffine(ref, np.float32([[1, 0, 0], [0, 1, 85]]), (640, 853), borderValue=(130,130,130))
    result = inspect(ref, candidate)
    assert result['status'] == 'clear'
    assert next(s for s in result['trace'] if s['tool']=='alignment')['evidence']['overlap_fraction'] > .75


def test_excessive_translation_rejected():
    ref = textured_portrait()
    candidate = cv2.warpAffine(ref, np.float32([[1, 0, 0], [0, 1, 160]]), (640, 853), borderValue=(130,130,130))
    assert inspect(ref, candidate)['status'] == 'retake'
